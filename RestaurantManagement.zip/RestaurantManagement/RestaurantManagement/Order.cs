﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace RestaurantManagement
{
    public partial class Order : Form
    {
        private DataAccess Da { get; set; }
        private string sql { get; set; }
        public Order(String id)
        {
            InitializeComponent();
            Da = new DataAccess();
            txtename.Text = id;
            txtename.ReadOnly = true;
            IdGenerator();
            COM();
            this.dateTimePicker.Value = DateTime.Now;
        }

        private void IdGenerator()
        {
            try
            {                
                    this.sql = "select * from placeitem order by id desc";
                    DataTable dt = this.Da.ExecuteQueryTable(sql);
                    string id = dt.Rows[0]["id"].ToString();
                    string[] str = id.Split('A');
                    int num = Convert.ToInt32(str[1]);
                    string newId = "A" + (++num).ToString();
                    txtorid.Text = newId.ToString();               
              

            }
            catch (Exception b) { }

        }

        //populategv
        public void PopulateGridView()
        {
            this.dataGridVieworder.AutoGenerateColumns = true;
        }
        private void Order_Load(object sender, EventArgs e)
        {
          

        }
        //combocatagory from db
        private void COM()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-D34E1ME;Initial Catalog=restaurantdb;Integrated Security=True;User ID=sa;Password=123456");
            string s = "select Catagory  from menuitem;";
            SqlCommand cmd = new SqlCommand(s, con);

            SqlDataReader myr;

            con.Open();
            myr = cmd.ExecuteReader();

            while (myr.Read())
            {
                string item = myr.GetString(0);
                combocatagory.Items.Add(item);
            }
            
        }

        //combocatagory to comboitem
        private void combocatagory_selectitem(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-D34E1ME;Initial Catalog=restaurantdb;Integrated Security=True;User ID=sa;Password=123456");
            string s = "select Item from menuitem where Catagory = '" + combocatagory.Text + "';";
            SqlCommand cmd = new SqlCommand(s, con);
            ClearAll();
            SqlDataReader myr;
            con.Open();
            myr = cmd.ExecuteReader();

            while (myr.Read())
            {
                string item = myr.GetString(0);
                comboitem.Items.Add(item);
                txtpriceitem.BackColor = Color.White;
                txtstock.ResetText();
                txtstock.BackColor = Color.FromArgb(23, 35, 49);
                lblstatus.BackColor = Color.FromArgb(23, 35, 49);
                numericUpDown.BackColor = Color.White;
            }
        }

        //price select func
        private void price() {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-D34E1ME;Initial Catalog=restaurantdb;Integrated Security=True;User ID=sa;Password=123456");
            string s = "select Price from menuitem where Item = '" + comboitem.Text + "';";
            SqlCommand cmd = new SqlCommand(s, con);

            SqlDataReader myr;

            con.Open();
            myr = cmd.ExecuteReader();

            while (myr.Read())
            {
                string price = myr.GetValue(0).ToString();
                txtpriceitem.Text = price;
            }
        }

        //stoke management
        private void stoke()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-D34E1ME;Initial Catalog=restaurantdb;Integrated Security=True;User ID=sa;Password=123456");
            string s = "select instoke from menuitem where Item = '" + comboitem.Text + "';";
            SqlCommand cmd = new SqlCommand(s, con);

            SqlDataReader myr;

            con.Open();
            myr = cmd.ExecuteReader();

            while (myr.Read())
            {
                string stoke = myr.GetValue(0).ToString();
                txtstock.Text = stoke;
            }
        }

        // status select by item 
        private void priceselectitem(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-D34E1ME;Initial Catalog=restaurantdb;Integrated Security=True;User ID=sa;Password=123456");
            string s = "select Status from menuitem where Item = '" + comboitem.Text + "';";
            SqlCommand cmd = new SqlCommand(s, con);
            SqlDataReader myr;
            con.Open();
            myr = cmd.ExecuteReader();
            while (myr.Read())
            {
                string status = myr.GetValue(0).ToString();
                this.lblstatus.Text = status;
                if (status == "Available")
                {
                    lblstatus.BackColor = Color.Green;
                    price();
                    stoke();
                    txtstock.BackColor = Color.Green;
                    txtpriceitem.BackColor = Color.White;
                    txtpriceitem.BackColor = Color.White;
                    txtphoneno.BackColor = Color.White;
                    numericUpDown.BackColor = Color.White;
                    numericUpDown.Enabled = true;
                    combotype.BackColor = Color.White;
                    combotype.Enabled = true;
                }
                else
                {
                    txtpriceitem.Clear();
                    txtstock.ResetText();
                    lblstatus.BackColor = Color.Red;
                    txtpriceitem.BackColor = Color.Red;
                    numericUpDown.BackColor = Color.Red;
                    numericUpDown.Enabled = false;
                    combotype.BackColor = Color.Red;
                    combotype.Enabled = false;
                    combotype.ResetText();
                    txtstock.BackColor = Color.Red;
                    
                }

            }
        }

        //ordertype
        private void combotype_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (combotype.SelectedIndex == 0)
            {
                txtphoneno.BackColor = Color.Red;
                txtphoneno.ReadOnly = true;
            }
            else
            {
                txtphoneno.BackColor = Color.White;
                txtphoneno.ReadOnly = false;
            }
        }


        //Add to the Cart 
        float totalAmount = 0;
        private void btnaddtocart_Click(object sender, EventArgs e)
        {
            //validation
            if (this.combocatagory.Text == "" || this.comboitem.Text == "" || this.txtpriceitem.Text == ""
            || this.numericUpDown.Value.ToString() == "0" || this.combotype.Text == "")

            {
                MessageBox.Show("Please Fill properly !");
            }
            else
            {
                bool check = false;                                     //check item is already exists in dgv or not
                foreach (DataGridViewRow row in dataGridVieworder.Rows)
                {
                    if (row.Cells["Item"].Value.ToString() == comboitem.Text.ToString())
                    {
                        check = true;
                        break;
                    }
                }
                if (check)
                {
                    MessageBox.Show("This item already add to the cart!");
                }

                else
                {
                    float price = float.Parse(txtpriceitem.Text) * (int)numericUpDown.Value;
                    int stock = Convert.ToInt32(txtstock.Text.ToString()) - (int)numericUpDown.Value;
                    txtstock.Text = stock.ToString();
                    lblstatus.BackColor = Color.Green;                 
                   
                    {
                        {
                            
                            if (combotype.SelectedIndex == 0)     //index by take
                            {
                                dataGridVieworder.Rows.Add(this.txtorid.Text, this.combocatagory.Text, this.comboitem.Text, this.txtpriceitem.Text,
                                (int)numericUpDown.Value, this.combotype.Text, this.dateTimePicker.Value = DateTime.Now, this.txtename.Text, "", price);
                                totalAmount += price;
                                txttotalprice.Text = totalAmount.ToString();
                                updatestock();
                            }
                            if (combotype.SelectedIndex == 1)

                            {
                                if (txtphoneno.Text == "") { MessageBox.Show("Phone no Missing!"); }
                                else
                                {
                                    dataGridVieworder.Rows.Add(this.txtorid.Text, this.combocatagory.Text, this.comboitem.Text, this.txtpriceitem.Text,
                                    (int)numericUpDown.Value, this.combotype.Text, this.dateTimePicker.Value = DateTime.Now, this.txtename.Text, this.txtphoneno.Text, price);
                                    totalAmount += price;
                                    txttotalprice.Text = totalAmount.ToString();
                                    updatestock();
                                }
                            }
                            this.PopulateGridView();
                        }

                    }
                }
            }
        }

        //Removing order
        private void remove_order(object sender, DataGridViewCellEventArgs e)
        {           
            if (e.RowIndex != -1 && (e.ColumnIndex != 1))
            {
                if (e.ColumnIndex == 10)
                {
                    DataGridViewRow row = dataGridVieworder.Rows[e.RowIndex];
                    float prc = Convert.ToSingle(row.Cells[9].Value);
                    string item = row.Cells[2].Value.ToString();
                    int quantity = Convert.ToInt32(row.Cells[4].Value);
                    int stock = Convert.ToInt32(txtstock.Text.ToString()) + quantity;
                    if (comboitem.Text == item) 
                    {
                        totalAmount -= prc;
                        txttotalprice.Text = totalAmount.ToString();               
                        txtstock.Text = stock.ToString();
                        updatestock();
                        dataGridVieworder.Rows.Remove(row);
                        
                    }                      
                        else
                            MessageBox.Show("Please double click the order Match the item and press remove!");                      
                       
                   }
            }
        }      

        //Orderplace
        private void btnorderplace_Click(object sender, EventArgs e)
        {

            if (txtreceiveamount.Text == "" || txttotalprice.Text == "0" || txttotalprice.Text == ""
                || totalAmount > float.Parse(txtreceiveamount.Text))
            {
                MessageBox.Show("Input wrong Amount try again!!");

            }
            else                                                                  //dgv to db insertion
            {

                for (int i = 0; i < dataGridVieworder.Rows.Count; i++)
                {

                    SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-D34E1ME;Initial Catalog=restaurantdb;Integrated Security=True;User ID=sa;Password=123456");
                    SqlCommand cmd = new SqlCommand("insert into placeitem (id,catagory,item,price,quantity,type,date,employee,phone,total)values(@id,@catagory,@item,@unitprice,@quantity,@ordertype,@date,@employee,@phone,@total)", con);
                    cmd.Parameters.AddWithValue("@id", dataGridVieworder.Rows[i].Cells[0].Value.ToString());
                    cmd.Parameters.AddWithValue("@catagory", dataGridVieworder.Rows[i].Cells[1].Value.ToString());
                    cmd.Parameters.AddWithValue("@item", dataGridVieworder.Rows[i].Cells[2].Value.ToString());
                    cmd.Parameters.AddWithValue("@unitprice", dataGridVieworder.Rows[i].Cells[3].Value.ToString());
                    cmd.Parameters.AddWithValue("@quantity", dataGridVieworder.Rows[i].Cells[4].Value.ToString());
                    cmd.Parameters.AddWithValue("@ordertype", dataGridVieworder.Rows[i].Cells[5].Value.ToString());
                    cmd.Parameters.AddWithValue("@date", dataGridVieworder.Rows[i].Cells[6].Value.ToString()); ;
                    cmd.Parameters.AddWithValue("@employee", dataGridVieworder.Rows[i].Cells[7].Value.ToString());
                    cmd.Parameters.AddWithValue("@phone", dataGridVieworder.Rows[i].Cells[8].Value.ToString());
                    cmd.Parameters.AddWithValue("@total", dataGridVieworder.Rows[i].Cells[9].Value.ToString());


                    con.Open();
                    cmd.ExecuteNonQuery();
                }             
                
                    float returnAmount = float.Parse(txtreceiveamount.Text) - this.totalAmount;
                    txtreturnamount.Text = returnAmount.ToString();            
                    MessageBox.Show("Order Place successfully!");                   
                    ClearAll();
                    txtstock.BackColor = Color.FromArgb(23, 35, 49);
                    lblstatus.BackColor = Color.FromArgb(23, 35, 49);
                    txttotalprice.Clear();
                    txtreceiveamount.Clear();
                    txtreturnamount.Clear();
                    dataGridVieworder.Rows.Clear();
                    IdGenerator();
                    totalAmount = 0;
            }
        }

       // Stock check
        private void updatestock() 
        {          
           this.sql = " update menuitem set instoke='"+txtstock.Text+"' where item='"+comboitem.Text+"';";
           this.Da.ExecuteUpdateQuery(this.sql);          
        }
        
      /*  //order cancel
        private void btncancel_Click(object sender, EventArgs e)
        {
            if (txttotalprice.Text == "" || txttotalprice.Text == "0")             //validate
            {
                MessageBox.Show("Empty Order! don't need to be cancel ! ");
            }
            else
            {
                if (MessageBox.Show("Are you sure cancel this order?", "Message", MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    ClearAll();
                    txttotalprice.Clear();
                    txtreceiveamount.Clear();
                    txtreturnamount.Clear();
                    dataGridVieworder.Rows.Clear();
                    txtstock.BackColor = Color.FromArgb(23, 35, 49);
                    lblstatus.BackColor = Color.FromArgb(23, 35, 49);

                }
                totalAmount = 0;
            }
            
        }      
        */

        //clearfunction
        public void ClearAll()
        {           
            this.combocatagory.ResetText();
            this.comboitem.ResetText();
            this.comboitem.Items.Clear();         
            this.txtpriceitem.Clear();
            this.numericUpDown.ResetText();
            this.txtphoneno.Clear();
            this.combotype.ResetText();
            this.lblstatus.ResetText();
            this.txtstock.ResetText();                    
        }      
        
        private void button1_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            l.Show();
            this.Hide();
        }

        private void quantityset(object sender, EventArgs e)
        {
            this.combocatagory.Text = this.dataGridVieworder.CurrentRow.Cells[1].Value.ToString();
            this.comboitem.Text = this.dataGridVieworder.CurrentRow.Cells[2].Value.ToString();
        }        
    }   
}
