﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace RestaurantManagement
{
    public partial class Login : Form
    {
        private DataAccess Da { get; set; }
        private DataSet Ds { get; set; }
        private string sql { get; set; }
        public Login()
        {
            InitializeComponent();           
            this.txtpass.AutoSize = false;
            this.txtpass.Size = new Size(this.txtpass.Size.Width, 28);
        }


        private void Login_Load(object sender, EventArgs e)
        {
           
        }


        private void btnsignin_Click_1(object sender, EventArgs e)
        {
            if (txtuid.Text == "" || txtpass.Text == "")
            {
                MessageBox.Show("Something Missing!Fill properly");
            }
            else
            {
                this.sql = "select type from Employee where id = '" + txtuid.Text + "' and Password = '" + txtpass.Text + "'";
                Da = new DataAccess();
                Ds = Da.ExecuteQuery(sql);
                if (Ds.Tables[0].Rows.Count == 1)
                {
                    switch (Ds.Tables[0].Rows[0]["type"].ToString())
                    {
                        case "Admin":
                            {
                                Dashboard d = new Dashboard();
                                d.Show();
                                this.Hide();

                                break;
                            }

                        case "Employee":
                            {
                                Order o = new Order(txtuid.Text);                               
                                o.Show();
                                this.Hide();
                                break;
                            }

                        default:
                            MessageBox.Show("Invalid User!");
                            break;
                    }
                }
                else { MessageBox.Show("User not found!incorrect id or password!"); }
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
