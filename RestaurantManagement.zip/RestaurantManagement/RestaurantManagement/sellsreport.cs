﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace RestaurantManagement
{
    public partial class sellsreport : Form
    {
        private DataAccess Da { get; set; }
        private DataSet Ds { get; set; }
        private string sql { get; set; }
        public sellsreport()
        {
            InitializeComponent();
            Da = new DataAccess();
            this.PopulateGridView();
            totalsell();
            this.dateTimePicker1.Value = DateTime.Now;
            this.dateTimePicker2.Value = DateTime.Now;
        }

        public void PopulateGridView(string sql = "select * from placeitem;") // load everytime
        {
            Da = new DataAccess();
            Ds = Da.ExecuteQuery(sql);
            this.Ds = this.Da.ExecuteQuery(sql);
            this.dataGridViewsell.AutoGenerateColumns = true;
            this.dataGridViewsell.DataSource = this.Ds.Tables[0];

        }


        private void sellsreport_Load(object sender, EventArgs e)
        {
           
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Dashboard d=new Dashboard();
            d.Show();
            this.Hide();
        }

        private void totalsell() 
        {
          int total = 0;
            for (int i = 0; i < dataGridViewsell.Rows.Count; i++) 
            {
                total += Convert.ToInt32(dataGridViewsell.Rows[i].Cells[10].Value);
            }
            txttotalsell.Text = total.ToString();
           

        }


        private void btnsrc2_Click(object sender, EventArgs e)
        {
            this.sql = "select * from placeitem where date between '" + dateTimePicker1.Value.ToString()+"' and '"+dateTimePicker2.Value.ToString()+"'";
            this.PopulateGridView(this.sql);
            totalsell();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnshow_Click(object sender, EventArgs e)
        {
            this.PopulateGridView();
            totalsell();
            txtsrc.Clear();
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            if (txtsrc.Text == "") { MessageBox.Show("Fill the box!"); }
            else
                try
                {
                    this.sql = "select * from placeitem where id= '" + this.txtsrc.Text + "' or catagory= '" + this.txtsrc.Text + "' or item='" + txtsrc.Text + "' or employee='" + txtsrc.Text + "'";
                    this.PopulateGridView(this.sql);
                    totalsell();
                   
                }
                catch { }
        }      
    }
}
