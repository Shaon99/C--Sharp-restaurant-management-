﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RestaurantManagement
{
    public partial class EmployeeInfo : Form
    {
        private DataAccess Da { get; set; }
        private DataSet Ds { get; set; }
        private string sql { get; set; }
        public EmployeeInfo()
        {
            InitializeComponent();
            this.PopulateGridView();
            txtid.ReadOnly = true;
            txtu.ReadOnly = true;
        }
        public void PopulateGridView(string sql = "select * from Employee;") // load everytime

        {
            Da = new DataAccess();
            Ds = Da.ExecuteQuery(sql);
            this.Ds = this.Da.ExecuteQuery(sql);


            this.dataGridViewem.AutoGenerateColumns = true;
            this.dataGridViewem.DataSource = this.Ds.Tables[0];

        }
       
        private void btnb_Click(object sender, EventArgs e)
        {
            Dashboard d = new Dashboard();
            d.Show();
            this.Hide();
        }


        private void doubleclicktotextbox(object sender, EventArgs e)
        {
            this.txtid.Text = this.dataGridViewem.CurrentRow.Cells[0].Value.ToString();
            this.txtname.Text = this.dataGridViewem.CurrentRow.Cells[1].Value.ToString();
            this.txtadd.Text = this.dataGridViewem.CurrentRow.Cells[2].Value.ToString();
            this.txtem.Text = this.dataGridViewem.CurrentRow.Cells[3].Value.ToString();
            this.txtphn.Text = this.dataGridViewem.CurrentRow.Cells[4].Value.ToString();
            this.txtpass.Text = this.dataGridViewem.CurrentRow.Cells[5].Value.ToString();
            this.txtu.Text = this.dataGridViewem.CurrentRow.Cells[6].Value.ToString();
            this. txtu.BackColor = Color.Red;
        }

        private void ClearAll()
        {
            txtid.Clear();
            this.txtid.Clear();
            this.txtname.Clear();
            this.txtadd.Clear();
            this.txtem.Clear();
            this.txtphn.Clear();
            this.txtpass.Clear();
            this.txtu.Clear();
            this.txtu.BackColor = Color.White;

        }

        //update
        private void btnup_Click(object sender, EventArgs e)
        {
            this.sql = @"update Employee
            set name= '" + this.txtname.Text + @"',
            address = '" + this.txtadd.Text + @"',
            email = '" + this.txtem.Text + @"',                        
            phone = '" + this.txtphn.Text + @"',
            password = '" + this.txtpass.Text +@"'                       
            where id = '" + this.txtid.Text + "';";
            int count = this.Da.ExecuteUpdateQuery(this.sql);
            if (count == 1)
            {
                MessageBox.Show("Employee Information updated");
            }
            else
            {
                MessageBox.Show("Double Click the file and update");
            }

            this.PopulateGridView();
            this.ClearAll();

        }
        //delete
        private void btnre_Click(object sender, EventArgs e)
        {
            try
            {
                string id = this.dataGridViewem.CurrentRow.Cells[0].Value.ToString();
                string name = this.dataGridViewem.CurrentRow.Cells[1].Value.ToString();


                this.sql = @"delete from Employee
                        where id = '" + id + "';";
                if (MessageBox.Show("Are you sure Remove the Employee?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    int count = this.Da.ExecuteUpdateQuery(this.sql);
                    if (count == 1)
                    {
                        MessageBox.Show(name+"\n"+ "Employee has been Remove From the System!");
                        ClearAll();
                    }
                }
                this.PopulateGridView();
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);

            }
        }

        //search
        private void button1_Click(object sender, EventArgs e)
        {
            if (txtsrc.Text == "")
            {
                MessageBox.Show("Write for Search");
            }
            else
            {
                this.sql = "select * from Employee where id= '" + this.txtsrc.Text + "'or name='" + txtsrc.Text + "'or type='" + txtsrc.Text + "'";
                this.PopulateGridView(this.sql);
            }
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.PopulateGridView();
        }
    }
}
