﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace RestaurantManagement
{
    public partial class EmployeeRegister : Form
    {
        private DataAccess Da { get; set; }
        private DataSet Ds { get; set; }
        private string sql { get; set; }


        public EmployeeRegister()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            IdGenerator();
            txteid.ReadOnly = true;
           
        }


        private void IdGenerator()
        {
            try
            {
                this.sql = "select * from Employee order by id desc ";
                DataTable dt = this.Da.ExecuteQueryTable(sql);
                string id = dt.Rows[0]["id"].ToString();
                string[] str = id.Split('E');
                int num = Convert.ToInt32(str[1]);
                string newId = "E" + (++num).ToString();
                txteid.Text = newId.ToString();

            }
            catch (Exception b) { }

        }


        private void ClearAll()
        {
                       
            this.txtename.Clear();
            this.txtaddress.Clear();
            this.txtemail.Clear();
            this.txtphone.Clear();
            this.txtpassword.Clear();
            IdGenerator();

        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Dashboard ad = new Dashboard();
            ad.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.txteid.Text == "" || this.txtename.Text == "" || this.txtaddress.Text == "" || this.txtemail.Text == "" ||
                this.txtphone.Text == "" || this.txtphone.Text == "")
            {
                MessageBox.Show("Something Missing!");
            }
            else
            {
                this.sql = @"insert into Employee(id,name,address,email,phone,password,type) values('" + this.txteid.Text + "','" + this.txtename.Text + "','" + this.txtaddress.Text + "','" + this.txtemail.Text + "','" + this.txtphone.Text + "','" + this.txtpassword.Text + "','"+this.comboBox1.Text+"');";
                Da = new DataAccess();
                Ds = Da.ExecuteQuery(sql);
                int count = Ds.Tables.Count;

                if (count != 1)
                {

                    MessageBox.Show("Signed-up Successfuly!" + "\nUser ID: " + txteid.Text + "\nPassword: " + txtpassword.Text);
                    

                }
                
                else
                {
                    MessageBox.Show("Invalid data");
                }
            }
            ClearAll();


        }

        private void EmployeeRegister_Load(object sender, EventArgs e)
        {

        }

        private void EmployeeRegister_Load_1(object sender, EventArgs e)
        {
           
        }
    }
}
