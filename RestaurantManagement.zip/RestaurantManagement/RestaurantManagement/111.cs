﻿namespace RestaurantManagementSystem
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnMenuSearch = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblMenuItemId = new System.Windows.Forms.Label();
            this.cmbMenuCategory = new System.Windows.Forms.ComboBox();
            this.txtMenuPrice = new System.Windows.Forms.TextBox();
            this.txtMenuInStock = new System.Windows.Forms.TextBox();
            this.txtMenuItem = new System.Windows.Forms.TextBox();
            this.txtMenuItemId = new System.Windows.Forms.TextBox();
            this.btnUpdateMenu = new System.Windows.Forms.Button();
            this.btnShowMenu = new System.Windows.Forms.Button();
            this.menuGridView = new System.Windows.Forms.DataGridView();
            this.restaurantManagementDBDataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.searchText = new System.Windows.Forms.TextBox();
            this.searchLabel = new System.Windows.Forms.Label();
            this.categoryLabel = new System.Windows.Forms.Label();
            this.categoryComboBox = new System.Windows.Forms.ComboBox();
            this.dashBoardLabel = new System.Windows.Forms.Label();
            this.directorySearcher1 = new System.DirectoryServices.DirectorySearcher();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.restaurantManagementDB1DataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnMenuAddItem = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menuGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantManagementDBDataSet1BindingSource)).BeginInit();
          
            ((System.ComponentModel.ISupportInitialize)(this.restaurantManagementDB1DataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnMenuAddItem);
            this.panel1.Controls.Add(this.btnMenuSearch);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lblMenuItemId);
            this.panel1.Controls.Add(this.cmbMenuCategory);
            this.panel1.Controls.Add(this.txtMenuPrice);
            this.panel1.Controls.Add(this.txtMenuInStock);
            this.panel1.Controls.Add(this.txtMenuItem);
            this.panel1.Controls.Add(this.txtMenuItemId);
            this.panel1.Controls.Add(this.btnUpdateMenu);
            this.panel1.Controls.Add(this.btnShowMenu);
            this.panel1.Controls.Add(this.menuGridView);
            this.panel1.Controls.Add(this.searchText);
            this.panel1.Controls.Add(this.searchLabel);
            this.panel1.Controls.Add(this.categoryLabel);
            this.panel1.Controls.Add(this.categoryComboBox);
            this.panel1.Controls.Add(this.dashBoardLabel);
            this.panel1.Location = new System.Drawing.Point(0, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(588, 450);
            this.panel1.TabIndex = 5;
            // 
            // btnMenuSearch
            // 
            this.btnMenuSearch.Location = new System.Drawing.Point(412, 205);
            this.btnMenuSearch.Name = "btnMenuSearch";
            this.btnMenuSearch.Size = new System.Drawing.Size(75, 23);
            this.btnMenuSearch.TabIndex = 28;
            this.btnMenuSearch.Text = "Search";
            this.btnMenuSearch.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 27;
            this.label4.Text = "Category";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 149);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 26;
            this.label3.Text = "Price";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 25;
            this.label2.Text = "In Stock";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 87);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 24;
            this.label1.Text = "Item";
            // 
            // lblMenuItemId
            // 
            this.lblMenuItemId.AutoSize = true;
            this.lblMenuItemId.Location = new System.Drawing.Point(21, 55);
            this.lblMenuItemId.Name = "lblMenuItemId";
            this.lblMenuItemId.Size = new System.Drawing.Size(41, 13);
            this.lblMenuItemId.TabIndex = 23;
            this.lblMenuItemId.Text = "Item ID";
            // 
            // cmbMenuCategory
            // 
            this.cmbMenuCategory.FormattingEnabled = true;
            this.cmbMenuCategory.Items.AddRange(new object[] {
            "Beverage",
            "Platter",
            "Soups",
            "Appetizer"});
            this.cmbMenuCategory.Location = new System.Drawing.Point(86, 169);
            this.cmbMenuCategory.Name = "cmbMenuCategory";
            this.cmbMenuCategory.Size = new System.Drawing.Size(140, 21);
            this.cmbMenuCategory.TabIndex = 22;
            this.cmbMenuCategory.SelectedIndexChanged += new System.EventHandler(this.cmbMenuCategory_SelectedIndexChanged);
            // 
            // txtMenuPrice
            // 
            this.txtMenuPrice.Location = new System.Drawing.Point(86, 142);
            this.txtMenuPrice.Name = "txtMenuPrice";
            this.txtMenuPrice.Size = new System.Drawing.Size(140, 20);
            this.txtMenuPrice.TabIndex = 20;
            // 
            // txtMenuInStock
            // 
            this.txtMenuInStock.Location = new System.Drawing.Point(86, 113);
            this.txtMenuInStock.Name = "txtMenuInStock";
            this.txtMenuInStock.Size = new System.Drawing.Size(140, 20);
            this.txtMenuInStock.TabIndex = 19;
            // 
            // txtMenuItem
            // 
            this.txtMenuItem.Location = new System.Drawing.Point(86, 84);
            this.txtMenuItem.Name = "txtMenuItem";
            this.txtMenuItem.Size = new System.Drawing.Size(140, 20);
            this.txtMenuItem.TabIndex = 18;
            this.txtMenuItem.TextChanged += new System.EventHandler(this.txtMenuItem_TextChanged);
            // 
            // txtMenuItemId
            // 
            this.txtMenuItemId.Location = new System.Drawing.Point(86, 52);
            this.txtMenuItemId.Name = "txtMenuItemId";
            this.txtMenuItemId.Size = new System.Drawing.Size(140, 20);
            this.txtMenuItemId.TabIndex = 17;
            // 
            // btnUpdateMenu
            // 
            this.btnUpdateMenu.Location = new System.Drawing.Point(303, 18);
            this.btnUpdateMenu.Name = "btnUpdateMenu";
            this.btnUpdateMenu.Size = new System.Drawing.Size(118, 23);
            this.btnUpdateMenu.TabIndex = 12;
            this.btnUpdateMenu.Text = "Update";
            this.btnUpdateMenu.UseVisualStyleBackColor = true;
            this.btnUpdateMenu.Click += new System.EventHandler(this.btnUpdateMenu_Click);
            // 
            // btnShowMenu
            // 
            this.btnShowMenu.Location = new System.Drawing.Point(427, 17);
            this.btnShowMenu.Name = "btnShowMenu";
            this.btnShowMenu.Size = new System.Drawing.Size(141, 23);
            this.btnShowMenu.TabIndex = 11;
            this.btnShowMenu.Text = "Show Menu";
            this.btnShowMenu.UseVisualStyleBackColor = true;
            this.btnShowMenu.Click += new System.EventHandler(this.btnShowMenu_Click);
            // 
            // menuGridView
            // 
            this.menuGridView.AutoGenerateColumns = false;
            this.menuGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.menuGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.menuGridView.DataSource = this.restaurantManagementDBDataSet1BindingSource;
            this.menuGridView.Location = new System.Drawing.Point(3, 234);
            this.menuGridView.Name = "menuGridView";
            this.menuGridView.ReadOnly = true;
            this.menuGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.menuGridView.Size = new System.Drawing.Size(582, 204);
            this.menuGridView.StandardTab = true;
            this.menuGridView.TabIndex = 10;
            this.menuGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // restaurantManagementDBDataSet1BindingSource
            // 
        
            this.restaurantManagementDBDataSet1BindingSource.Position = 0;
            // 
            // restaurantManagementDBDataSet1
            // 
        
            // 
            // searchText
            // 
            this.searchText.Location = new System.Drawing.Point(98, 208);
            this.searchText.Name = "searchText";
            this.searchText.Size = new System.Drawing.Size(96, 20);
            this.searchText.TabIndex = 9;
            // 
            // searchLabel
            // 
            this.searchLabel.AutoSize = true;
            this.searchLabel.Location = new System.Drawing.Point(48, 215);
            this.searchLabel.Name = "searchLabel";
            this.searchLabel.Size = new System.Drawing.Size(41, 13);
            this.searchLabel.TabIndex = 8;
            this.searchLabel.Text = "Search";
            // 
            // categoryLabel
            // 
            this.categoryLabel.AutoSize = true;
            this.categoryLabel.Location = new System.Drawing.Point(225, 211);
            this.categoryLabel.Name = "categoryLabel";
            this.categoryLabel.Size = new System.Drawing.Size(49, 13);
            this.categoryLabel.TabIndex = 6;
            this.categoryLabel.Text = "Category";
            this.categoryLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // categoryComboBox
            // 
            this.categoryComboBox.FormattingEnabled = true;
            this.categoryComboBox.Items.AddRange(new object[] {
            "Beverage",
            "Appetizer",
            "Platter",
            "Soups"});
            this.categoryComboBox.Location = new System.Drawing.Point(280, 207);
            this.categoryComboBox.Name = "categoryComboBox";
            this.categoryComboBox.Size = new System.Drawing.Size(97, 21);
            this.categoryComboBox.TabIndex = 5;
            this.categoryComboBox.SelectedIndexChanged += new System.EventHandler(this.categoryComboBox_SelectedIndexChanged);
            // 
            // dashBoardLabel
            // 
            this.dashBoardLabel.AutoSize = true;
            this.dashBoardLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dashBoardLabel.Location = new System.Drawing.Point(12, 11);
            this.dashBoardLabel.Name = "dashBoardLabel";
            this.dashBoardLabel.Size = new System.Drawing.Size(77, 29);
            this.dashBoardLabel.TabIndex = 4;
            this.dashBoardLabel.Text = "Menu";
            this.dashBoardLabel.Click += new System.EventHandler(this.dashBoardLabel_Click);
            // 
            // directorySearcher1
            // 
            this.directorySearcher1.ClientTimeout = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerPageTimeLimit = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerTimeLimit = System.TimeSpan.Parse("-00:00:01");
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // restaurantManagementDB1DataSet
            // 
          
            // 
            // restaurantManagementDB1DataSetBindingSource
            // 
         
            this.restaurantManagementDB1DataSetBindingSource.Position = 0;
            // 
            // btnMenuAddItem
            // 
            this.btnMenuAddItem.Location = new System.Drawing.Point(303, 67);
            this.btnMenuAddItem.Name = "btnMenuAddItem";
            this.btnMenuAddItem.Size = new System.Drawing.Size(118, 23);
            this.btnMenuAddItem.TabIndex = 29;
            this.btnMenuAddItem.Text = "Add Item";
            this.btnMenuAddItem.UseVisualStyleBackColor = true;
            this.btnMenuAddItem.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(588, 450);
            this.Controls.Add(this.panel1);
            this.Name = "Menu";
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.Menu_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menuGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantManagementDBDataSet1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantManagementDB1DataSetBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label dashBoardLabel;
        private System.Windows.Forms.Label categoryLabel;
        private System.Windows.Forms.ComboBox categoryComboBox;
        private System.DirectoryServices.DirectorySearcher directorySearcher1;
        private System.Windows.Forms.DataGridView menuGridView;
        private System.Windows.Forms.TextBox searchText;
        private System.Windows.Forms.Label searchLabel;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Button btnShowMenu;
        private System.Windows.Forms.BindingSource restaurantManagementDBDataSet1BindingSource;
        private System.Windows.Forms.BindingSource restaurantManagementDB1DataSetBindingSource;
        private System.Windows.Forms.Button btnUpdateMenu;
        private System.Windows.Forms.Button btnMenuSearch;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblMenuItemId;
        private System.Windows.Forms.ComboBox cmbMenuCategory;
        private System.Windows.Forms.TextBox txtMenuPrice;
        private System.Windows.Forms.TextBox txtMenuInStock;
        private System.Windows.Forms.TextBox txtMenuItem;
        private System.Windows.Forms.TextBox txtMenuItemId;
        private System.Windows.Forms.Button btnMenuAddItem;
    }
}