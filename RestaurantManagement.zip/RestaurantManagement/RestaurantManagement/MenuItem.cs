﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace RestaurantManagement
{
    public partial class MenuItem : Form
    {
        private DataAccess Da { get; set; }
        private DataSet Ds { get; set; }
        private string sql { get; set; }

        public MenuItem()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            this.PopulateGridView();
            IdGenerator();
            txtid.ReadOnly = true;

        }
        //id generator
        private void IdGenerator()
        {
           
                this.sql = "select * from menuitem order by itemid desc";
                DataTable dt = this.Da.ExecuteQueryTable(sql);
                string id = dt.Rows[0]["itemid"].ToString();
                string[] str = id.Split('M');
                int num = Convert.ToInt32(str[1]);
                string newId = "M" + (++num).ToString();
                txtid.Text = newId.ToString();          

        }

        public void PopulateGridView(string sql = "select * from menuitem;") // load everytime
        {
            Da = new DataAccess();
            //Ds = Da.ExecuteQuery(sql);
            this.Ds = this.Da.ExecuteQuery(sql);


            this.dataGridViewitem.AutoGenerateColumns = true;
            this.dataGridViewitem.DataSource = this.Ds.Tables[0];

        }
        private void MenuItem_Load(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Dashboard dash = new Dashboard();
            dash.Show();
            this.Hide();
          
        }

        private void ClearAll()
        {
           
            this.txtitem.Clear();
            this.txtprice.Clear();
            this.cmbic.ResetText();
            this.cmbs.ResetText();
            this.txtinstoke.Clear();
            this.IdGenerator();

        }

        //Add item
        private void btnadd_Click(object sender, EventArgs e)
        {
            try {
                if (this.txtid.Text == "" || this.txtitem.Text == "" || this.txtprice.Text == "" || this.cmbic.Text == "" || this.cmbs.Text == "")
                {

                    MessageBox.Show("Please Fill properly");

                }

                else
                {

                    this.sql = @"insert into menuitem
            values ('" + this.txtid.Text + "', '" + this.cmbic.Text + "', '" + this.txtitem.Text  + "','" + this.txtprice.Text  + "', '" + this.cmbs.Text + "','" + this.txtinstoke.Text + "');";

                    Da = new DataAccess();
                    int count = this.Da.ExecuteUpdateQuery(this.sql);
                    if (count == 1)
                    {
                        MessageBox.Show("Item added properly");

                    }
                }

                this.PopulateGridView();
                this.ClearAll();
                
            } catch (Exception ex) { MessageBox.Show("Item already exists!"); 
            }
        }
        
            
        //Delete Item
        private void btndlt_Click_1(object sender, EventArgs e)
        {
            try
            {
                string id = this.dataGridViewitem.CurrentRow.Cells[0].Value.ToString();
                string name = this.dataGridViewitem.CurrentRow.Cells[1].Value.ToString();


                this.sql = @"delete from menuitem
                        where Itemid = '" + id + "';";
                if (MessageBox.Show("Are you sure delete the iteam?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    int count = this.Da.ExecuteUpdateQuery(this.sql);
                    if (count == 1)
                    {
                        MessageBox.Show(name + "Item has been deleted");
                    }
                }
               this.PopulateGridView();
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);

            }
        }
                
        
     //update item               
        private void btnupd_Click(object sender, EventArgs e)
        {
            this.sql = @"update menuitem
                        set item = '" + this.txtitem.Text + @"',                        
                        catagory = '" + this.cmbic.Text + @"',
                        price = '" + this.txtprice.Text + @"',                        
                        status = '" + this.cmbs.Text + @"',
                        instoke = '" + this.txtinstoke.Text + @"'
                        where itemid = '" + this.txtid.Text + "';";
            int count = this.Da.ExecuteUpdateQuery(this.sql);
            if (count == 1)
            {
                MessageBox.Show("Item has been Updated");
            }
            else
            {
                MessageBox.Show("Please double click the row that u want to uapdate!");
            }

            this.PopulateGridView();
            this.ClearAll();
          
        }            
        
        private void btnshowview_Click(object sender, EventArgs e)
        {
            this.PopulateGridView();
        }

        // dcshow in box from dgv      
        private void doubleclick(object sender, EventArgs e)
        {
            this.txtid.Text = this.dataGridViewitem.CurrentRow.Cells[0].Value.ToString();
            this.cmbic.Text = this.dataGridViewitem.CurrentRow.Cells[1].Value.ToString();
            this.txtitem.Text = this.dataGridViewitem.CurrentRow.Cells[2].Value.ToString();
            this.txtprice.Text = this.dataGridViewitem.CurrentRow.Cells[3].Value.ToString();
            this.cmbs.Text = this.dataGridViewitem.CurrentRow.Cells[4].Value.ToString();
            this.txtinstoke.Text = this.dataGridViewitem.CurrentRow.Cells[5].Value.ToString();
        }
        //search
        private void btnsi_Click(object sender, EventArgs e)
        {
            if (txtsearch.Text=="") { MessageBox.Show("fill the box"); }
            else
            try
            {
                this.sql = "select * from menuitem where itemid= '" + this.txtsearch.Text + "' or catagory='" + txtsearch.Text + "' or item= '" + this.txtsearch.Text + "' or status='" + txtsearch.Text + "'";
                this.PopulateGridView(this.sql);
            }
            catch { }

        }
    }
}
    

                    

